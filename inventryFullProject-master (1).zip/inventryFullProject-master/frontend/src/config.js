const config = {
  API_URL: "http://localhost:9000/api",
};

module.exports = config;
